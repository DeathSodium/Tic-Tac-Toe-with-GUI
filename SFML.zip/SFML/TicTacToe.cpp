#include <SFML/Graphics.hpp>
#include <stack>
#include <queue>
#include <iostream>

using namespace std;
using namespace sf;

const char PLAYER_X = 'X';
const char PLAYER_O = 'O';
const char EMPTY = ' ';

// Node for the linked list representing the board
struct Node {
    char value;
    Node* next;
    Node(char val = EMPTY) : value(val), next(nullptr) {}
};

// Board represented as a linked list
struct Board {
    Node* head;
    int rows, cols;

    Board(int r, int c) : rows(r), cols(c) {
        head = nullptr;
        Node* tail = nullptr;
        for (int i = 0; i < r * c; ++i) {
            Node* newNode = new Node();
            if (!head) {
                head = newNode;
            }
            else {
                tail->next = newNode;
            }
            tail = newNode;
        }
    }

    ~Board() {
        Node* current = head;
        while (current) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
    }

    // Access board cell (row, col) using linked list traversal
    Node* getCell(int row, int col) {
        int index = row * cols + col;
        Node* current = head;
        while (index-- > 0 && current) {
            current = current->next;
        }
        return current;
    }

    // Set value at (row, col)
    void setCell(int row, int col, char value) {
        Node* cell = getCell(row, col);
        if (cell) cell->value = value;
    }

    // Get value at (row, col)
    char getCellValue(int row, int col) {
        Node* cell = getCell(row, col);
        return cell ? cell->value : EMPTY;
    }

    // Check if board is full
    bool isFull() {
        Node* current = head;
        while (current) {
            if (current->value == EMPTY) return false;
            current = current->next;
        }
        return true;
    }

    // Reset the board
    void reset() {
        Node* current = head;
        while (current) {
            current->value = EMPTY;
            current = current->next;
        }
    }
};

// Button class for menu interaction
class Button {
public:
    Button(const std::string& text, const sf::Font& font, const sf::Vector2f& position, const sf::Vector2f& size) {
        buttonShape.setSize(size);
        buttonShape.setFillColor(Color::White);
        buttonShape.setPosition(position);

        buttonText.setFont(font);
        buttonText.setString(text);
        buttonText.setCharacterSize(30);
        buttonText.setFillColor(Color::Black);
        buttonText.setPosition(position.x + 20, position.y + 10);
    }

    void draw(RenderWindow& window) {
        window.draw(buttonShape);
        window.draw(buttonText);
    }

    bool isClicked(const Vector2i& mousePos) {
        return buttonShape.getGlobalBounds().contains(static_cast<Vector2f>(mousePos));
    }

private:
    RectangleShape buttonShape;
    Text buttonText;
};

// Function declarations
bool checkWin(Board& board, char player);
void drawBoard(RenderWindow& window, Board& board, Sprite& backgroundSprite, Texture& xTexture, Texture& oTexture, int cellSize);
int showMenu(RenderWindow& window, const Font& font, Sprite& backgroundSprite);
int showRestartPrompt(RenderWindow& window, const Font& font, Sprite& backgroundSprite);
void playerMove(Board& board, char player, int row, int col);
void cpuMove(Board& board, char player);
int minimax(Board& board, int depth, bool isMaximizing, char player, int alpha, int beta);

int main() {
    RenderWindow window(VideoMode(600, 600), "Tic Tac Toe", Style::Resize | Style::Close);
    window.setFramerateLimit(60);

    // Load assets
    Texture backgroundTexture, xTexture, oTexture;
    if (!backgroundTexture.loadFromFile("D:\\University\\Assignments\\DSA lab\\Project\\SFML\\Assets\\BG.png")) {
        cerr << "Error: Could not load background image!" << endl;
        return -1;
    }
    if (!xTexture.loadFromFile("D:\\University\\Assignments\\DSA lab\\Project\\SFML\\Assets\\X.png")) {
        cerr << "Error: Could not load X image!" << endl;
        return -1;
    }
    if (!oTexture.loadFromFile("D:\\University\\Assignments\\DSA lab\\Project\\SFML\\Assets\\O.png")) {
        cerr << "Error: Could not load O image!" << endl;
        return -1;
    }

    // Set background sprite
    Sprite backgroundSprite;
    backgroundSprite.setTexture(backgroundTexture);

    Font font;
    if (!font.loadFromFile("D:\\University\\Assignments\\DSA lab\\Project\\SFML\\Assets\\arial.ttf")) {
        cerr << "Error: Could not load font!" << endl;
        return -1;
    }

    // Initialize board
    Board board(3, 3);
    char currentPlayer = PLAYER_X;

    // Show menu
    int mode = showMenu(window, font, backgroundSprite);

    // Main game loop
    while (window.isOpen()) {
        int cellSize = min(window.getSize().x / 3, window.getSize().y / 3);

        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }
            if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
                int col = event.mouseButton.x / cellSize;
                int row = event.mouseButton.y / cellSize;

                if (board.getCellValue(row, col) == EMPTY) {
                    playerMove(board, currentPlayer, row, col);
                    if (checkWin(board, currentPlayer)) {
                        window.clear();
                        drawBoard(window, board, backgroundSprite, xTexture, oTexture, cellSize);
                        window.display();
                        cout << "Player " << currentPlayer << " wins!" << endl;
                        if (showRestartPrompt(window, font, backgroundSprite)) {
                            board.reset();
                            currentPlayer = PLAYER_X;
                        }
                        else {
                            window.close();
                        }
                    }
                    if (board.isFull()) {
                        window.clear();
                        drawBoard(window, board, backgroundSprite, xTexture, oTexture, cellSize);
                        window.display();
                        cout << "It's a draw!" << endl;
                        if (showRestartPrompt(window, font, backgroundSprite)) {
                            board.reset();
                            currentPlayer = PLAYER_X;
                        }
                        else {
                            window.close();
                        }
                    }
                    currentPlayer = (currentPlayer == PLAYER_X) ? PLAYER_O : PLAYER_X;
                }
            }
        }

        if (mode == 2 && currentPlayer == PLAYER_O) {
            cpuMove(board, PLAYER_O);
            if (checkWin(board, PLAYER_O)) {
                cout << "CPU (O) wins!" << endl;
                if (showRestartPrompt(window, font, backgroundSprite)) {
                    board.reset();
                    currentPlayer = PLAYER_X;
                }
                else {
                    window.close();
                }
            }
            if (board.isFull()) {
                cout << "It's a draw!" << endl;
                if (showRestartPrompt(window, font, backgroundSprite)) {
                    board.reset();
                    currentPlayer = PLAYER_X;
                }
                else {
                    window.close();
                }
            }
            currentPlayer = PLAYER_X;
        }

        window.clear();
        drawBoard(window, board, backgroundSprite, xTexture, oTexture, cellSize);
        window.display();
    }

    return 0;
}

// Menu function
int showMenu(RenderWindow& window, const Font& font, Sprite& backgroundSprite) {
    Button playerVsPlayer("Player vs Player", font, { 150, 200 }, { 300, 50 });
    Button playerVsCPU("Player vs CPU", font, { 150, 300 }, { 300, 50 });
    Button exitGame("Exit", font, { 150, 400 }, { 300, 50 });

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
                return -1;
            }
            if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
                Vector2i mousePos = Mouse::getPosition(window);
                if (playerVsPlayer.isClicked(mousePos)) return 1; // Player vs Player
                if (playerVsCPU.isClicked(mousePos)) return 2;    // Player vs CPU
                if (exitGame.isClicked(mousePos)) return -1;      // Exit
            }
        }

        window.clear();
        window.draw(backgroundSprite);
        playerVsPlayer.draw(window);
        playerVsCPU.draw(window);
        exitGame.draw(window);
        window.display();
    }
    return -1;
}

void drawBoard(RenderWindow& window, Board& board, Sprite& backgroundSprite, Texture& xTexture, Texture& oTexture, int cellSize) {
    window.draw(backgroundSprite);

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            char cellValue = board.getCellValue(i, j);
            if (cellValue != EMPTY) {
                Sprite sprite;
                sprite.setTexture((cellValue == PLAYER_X) ? xTexture : oTexture);
                sprite.setScale(Vector2f(
                    static_cast<float>(cellSize) / xTexture.getSize().x,
                    static_cast<float>(cellSize) / xTexture.getSize().y
                ));
                sprite.setPosition(j * cellSize, i * cellSize);
                window.draw(sprite);
            }
        }
    }
}

// Show restart prompt
int showRestartPrompt(RenderWindow& window, const Font& font, Sprite& backgroundSprite) {
    Text text("Restart? (Y/N)", font, 50);
    text.setFillColor(Color::White);
    text.setPosition(150, 250);

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }
            if (event.type == Event::KeyPressed) {
                if (event.key.code == Keyboard::Y) return 1; // Restart
                if (event.key.code == Keyboard::N) return 0; // Quit
            }
        }

        window.clear();
        window.draw(backgroundSprite);
        window.draw(text);
        window.display();
    }
    return 0;
}

// Player move
void playerMove(Board& board, char player, int row, int col) {
    board.setCell(row, col, player);
}

// CPU move using Minimax
void cpuMove(Board& board, char player) {
    int bestScore = -1000;
    int moveRow = -1, moveCol = -1;

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (board.getCellValue(i, j) == EMPTY) {
                board.setCell(i, j, player);
                int score = minimax(board, 0, false, player, -1000, 1000);
                board.setCell(i, j, EMPTY);
                if (score > bestScore) {
                    bestScore = score;
                    moveRow = i;
                    moveCol = j;
                }
            }
        }
    }

    board.setCell(moveRow, moveCol, player);
    cout << "CPU chooses: " << moveRow << " " << moveCol << endl;
}

// Minimax with Alpha-Beta Pruning
int minimax(Board& board, int depth, bool isMaximizing, char player, int alpha, int beta) {
    char opponent = (player == PLAYER_X) ? PLAYER_O : PLAYER_X;

    if (checkWin(board, player)) return 10 - depth;
    if (checkWin(board, opponent)) return depth - 10;
    if (board.isFull()) return 0;

    int bestScore = isMaximizing ? -1000 : 1000;

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (board.getCellValue(i, j) == EMPTY) {
                board.setCell(i, j, isMaximizing ? player : opponent);
                int score = minimax(board, depth + 1, !isMaximizing, player, alpha, beta);
                board.setCell(i, j, EMPTY);

                if (isMaximizing) {
                    bestScore = max(bestScore, score);
                    alpha = max(alpha, bestScore);
                }
                else {
                    bestScore = min(bestScore, score);
                    beta = min(beta, bestScore);
                }

                if (beta <= alpha) return bestScore;
            }
        }
    }

    return bestScore;
}

// Check if a player has won
bool checkWin(Board& board, char player) {
    for (int i = 0; i < 3; ++i) {
        if (board.getCellValue(i, 0) == player && board.getCellValue(i, 1) == player &&
            board.getCellValue(i, 2) == player)
            return true;
        if (board.getCellValue(0, i) == player && board.getCellValue(1, i) == player &&
            board.getCellValue(2, i) == player)
            return true;
    }
    if (board.getCellValue(0, 0) == player && board.getCellValue(1, 1) == player &&
        board.getCellValue(2, 2) == player)
        return true;
    if (board.getCellValue(0, 2) == player && board.getCellValue(1, 1) == player &&
        board.getCellValue(2, 0) == player)
        return true;

    return false;
}