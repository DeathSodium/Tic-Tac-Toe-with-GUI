#include <SFML/Graphics.hpp>
#include <stack>
#include <queue>
#include <iostream>

using namespace std;
using namespace sf;

// Constants to represent players and empty cells
const char PLAYER_X = 'X';
const char PLAYER_O = 'O';
const char EMPTY = ' ';

// Node structure for the linked list representation of the game board
struct Node {
    char value;      // Value in the cell (X, O, or EMPTY)
    Node* next;      // Pointer to the next node in the linked list
    Node(char val = EMPTY) : value(val), next(nullptr) {}
};

// Linked list representation of the game board
struct Board {
    Node* head;      // Pointer to the first node in the board
    int rows, cols;  // Dimensions of the board

    // Constructor to initialize the board with given rows and columns
    Board(int r, int c) : rows(r), cols(c) {
        head = nullptr;
        Node* tail = nullptr;
        for (int i = 0; i < r * c; ++i) {
            Node* newNode = new Node();
            if (!head) { // If the list is empty, initialize head
                head = newNode;
            }
            else { // Otherwise, link the new node to the list
                tail->next = newNode;
            }
            tail = newNode; // Update tail to the new last node
        }
    }

    // Destructor to clean up the memory used by the board
    ~Board() {
        Node* current = head;
        while (current) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
    }

    // Get the pointer to a specific cell using row and column indices
    Node* getCell(int row, int col) {
        int index = row * cols + col; // Calculate the linear index
        Node* current = head;
        while (index-- > 0 && current) {
            current = current->next; // Traverse the list to the target node
        }
        return current;
    }

    // Set the value of a specific cell
    void setCell(int row, int col, char value) {
        Node* cell = getCell(row, col);
        if (cell) cell->value = value; // Update the cell value if the node exists
    }

    // Get the value of a specific cell
    char getCellValue(int row, int col) {
        Node* cell = getCell(row, col);
        return cell ? cell->value : EMPTY; // Return the value or EMPTY if invalid
    }

    // Check if the board is full (no more valid moves)
    bool isFull() {
        Node* current = head;
        while (current) {
            if (current->value == EMPTY) return false; // Found an empty cell
            current = current->next;
        }
        return true; // All cells are occupied
    }

    // Reset the board to its initial empty state
    void reset() {
        Node* current = head;
        while (current) {
            current->value = EMPTY;
            current = current->next;
        }
    }
};

// Class to represent buttons for menu options
class Button {
public:
    // Constructor to set up the button with text, font, position, and size
    Button(const std::string& text, const sf::Font& font, const sf::Vector2f& position, const sf::Vector2f& size) {
        buttonShape.setSize(size);
        buttonShape.setFillColor(Color::White);
        buttonShape.setPosition(position);

        buttonText.setFont(font);
        buttonText.setString(text);
        buttonText.setCharacterSize(30);
        buttonText.setFillColor(Color::Black);
        buttonText.setPosition(position.x + 20, position.y + 10);
    }

    // Draw the button on the screen
    void draw(RenderWindow& window) {
        window.draw(buttonShape);
        window.draw(buttonText);
    }

    // Check if the button was clicked based on the mouse position
    bool isClicked(const Vector2i& mousePos) {
        return buttonShape.getGlobalBounds().contains(static_cast<Vector2f>(mousePos));
    }

private:
    RectangleShape buttonShape; // Shape of the button
    Text buttonText;            // Text displayed on the button
};

// Function declarations
bool checkWin(Board& board, char player); // Check if a player has won
void drawBoard(RenderWindow& window, Board& board, Sprite& backgroundSprite, Texture& xTexture, Texture& oTexture, int cellSize);
int showMenu(RenderWindow& window, const Font& font, Sprite& backgroundSprite);
int showRestartPrompt(RenderWindow& window, const Font& font, Sprite& backgroundSprite);
void playerMove(Board& board, char player, int row, int col);
void cpuMove(Board& board, char player);
int minimax(Board& board, int depth, bool isMaximizing, char player, int alpha, int beta);

int main() {
    RenderWindow window(VideoMode(600, 600), "Tic Tac Toe", Style::Resize | Style::Close);
    window.setFramerateLimit(60); // Limit frame rate for smoother performance

    // Load textures and font
    Texture backgroundTexture, xTexture, oTexture;
    if (!backgroundTexture.loadFromFile("D:\\University\\Assignments\\DSA lab\\Project\\SFML\\Assets\\BG.png")) {
        cerr << "Error: Could not load background image!" << endl;
        return -1;
    }
    if (!xTexture.loadFromFile("D:\\University\\Assignments\\DSA lab\\Project\\SFML\\Assets\\X.png")) {
        cerr << "Error: Could not load X image!" << endl;
        return -1;
    }
    if (!oTexture.loadFromFile("D:\\University\\Assignments\\DSA lab\\Project\\SFML\\Assets\\O.png")) {
        cerr << "Error: Could not load O image!" << endl;
        return -1;
    }

    Sprite backgroundSprite;
    backgroundSprite.setTexture(backgroundTexture);

    Font font;
    if (!font.loadFromFile("D:\\University\\Assignments\\DSA lab\\Project\\SFML\\Assets\\arial.ttf")) {
        cerr << "Error: Could not load font!" << endl;
        return -1;
    }

    Board board(3, 3); // Initialize the game board
    char currentPlayer = PLAYER_X;

    int mode = showMenu(window, font, backgroundSprite); // Show menu to select game mode

    // Main game loop
    while (window.isOpen()) {
        int cellSize = min(window.getSize().x / 3, window.getSize().y / 3); // Adjust cell size dynamically

        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close(); // Exit the game
            }
            if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
                int col = event.mouseButton.x / cellSize;
                int row = event.mouseButton.y / cellSize;

                if (board.getCellValue(row, col) == EMPTY) { // Handle player move
                    playerMove(board, currentPlayer, row, col);
                    if (checkWin(board, currentPlayer)) {
                        window.clear();
                        drawBoard(window, board, backgroundSprite, xTexture, oTexture, cellSize);
                        window.display();
                        cout << "Player " << currentPlayer << " wins!" << endl;
                        if (showRestartPrompt(window, font, backgroundSprite)) {
                            board.reset();
                            currentPlayer = PLAYER_X;
                        }
                        else {
                            window.close();
                        }
                    }
                    if (board.isFull()) { // Handle draw
                        window.clear();
                        drawBoard(window, board, backgroundSprite, xTexture, oTexture, cellSize);
                        window.display();
                        cout << "It's a draw!" << endl;
                        if (showRestartPrompt(window, font, backgroundSprite)) {
                            board.reset();
                            currentPlayer = PLAYER_X;
                        }
                        else {
                            window.close();
                        }
                    }
                    currentPlayer = (currentPlayer == PLAYER_X) ? PLAYER_O : PLAYER_X; // Switch turn
                }
            }
        }

        if (mode == 2 && currentPlayer == PLAYER_O) { // Handle CPU move
            cpuMove(board, PLAYER_O);
            if (checkWin(board, PLAYER_O)) {
                cout << "CPU (O) wins!" << endl;
                if (showRestartPrompt(window, font, backgroundSprite)) {
                    board.reset();
                    currentPlayer = PLAYER_X;
                }
                else {
                    window.close();
                }
            }
            if (board.isFull()) {
                cout << "It's a draw!" << endl;
                if (showRestartPrompt(window, font, backgroundSprite)) {
                    board.reset();
                    currentPlayer = PLAYER_X;
                }
                else {
                    window.close();
                }
            }
            currentPlayer = PLAYER_X;
        }

        window.clear();
        drawBoard(window, board, backgroundSprite, xTexture, oTexture, cellSize);
        window.display();
    }

    return 0;
}

// The remaining functions have comments in similar detail.
int showMenu(RenderWindow& window, const Font& font, Sprite& backgroundSprite) {
    // Create buttons for the menu options
    Button playerVsPlayer("Player vs Player", font, { 150, 200 }, { 300, 50 });
    Button playerVsCPU("Player vs CPU", font, { 150, 300 }, { 300, 50 });
    Button exitGame("Exit", font, { 150, 400 }, { 300, 50 });

    // Loop to handle menu interactions
    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close(); // Exit the application
                return -1;
            }
            if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
                Vector2i mousePos = Mouse::getPosition(window); // Get mouse position
                if (playerVsPlayer.isClicked(mousePos)) return 1; // Player vs Player
                if (playerVsCPU.isClicked(mousePos)) return 2;    // Player vs CPU
                if (exitGame.isClicked(mousePos)) return -1;      // Exit
            }
        }

        // Render the menu
        window.clear();
        window.draw(backgroundSprite);
        playerVsPlayer.draw(window);
        playerVsCPU.draw(window);
        exitGame.draw(window);
        window.display();
    }
    return -1;
}

void drawBoard(RenderWindow& window, Board& board, Sprite& backgroundSprite, Texture& xTexture, Texture& oTexture, int cellSize) {
    window.draw(backgroundSprite); // Draw the background image

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            char cellValue = board.getCellValue(i, j);
            if (cellValue != EMPTY) { // Only draw occupied cells
                Sprite sprite;
                sprite.setTexture((cellValue == PLAYER_X) ? xTexture : oTexture);
                // Scale the texture to fit the cell
                sprite.setScale(Vector2f(
                    static_cast<float>(cellSize) / xTexture.getSize().x,
                    static_cast<float>(cellSize) / xTexture.getSize().y
                ));
                sprite.setPosition(j * cellSize, i * cellSize); // Position in the grid
                window.draw(sprite);
            }
        }
    }
}

int showRestartPrompt(RenderWindow& window, const Font& font, Sprite& backgroundSprite) {
    // Buttons for "Yes" and "No" options
    Button yesButton("Yes", font, { 150, 200 }, { 150, 50 });
    Button noButton("No", font, { 150, 300 }, { 150, 50 });

    // Text prompting the player for a restart
    Text text("Restart?", font, 50);
    text.setFillColor(Color::White);
    text.setPosition(150, 100);

    // Loop to handle the restart prompt
    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
                return 0; // Quit the game
            }
            if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
                Vector2i mousePos = Mouse::getPosition(window);
                if (yesButton.isClicked(mousePos)) return 1; // Restart the game
                if (noButton.isClicked(mousePos)) return 0;  // Quit the game
            }
        }

        // Render the restart prompt
        window.clear();
        window.draw(backgroundSprite);
        window.draw(text);
        yesButton.draw(window);
        noButton.draw(window);
        window.display();
    }
    return 0;
}

void playerMove(Board& board, char player, int row, int col) {
    board.setCell(row, col, player); // Update the board with the player's move
}

void cpuMove(Board& board, char player) {
    int bestScore = -1000; // CPU tries to maximize its score
    int moveRow = -1, moveCol = -1; // Track the best move

    // Evaluate all possible moves
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (board.getCellValue(i, j) == EMPTY) { // Only consider empty cells
                board.setCell(i, j, player); // Simulate the move
                int score = minimax(board, 0, false, player, -1000, 1000); // Evaluate using Minimax
                board.setCell(i, j, EMPTY); // Undo the move
                if (score > bestScore) { // Update the best move
                    bestScore = score;
                    moveRow = i;
                    moveCol = j;
                }
            }
        }
    }

    // Make the best move
    board.setCell(moveRow, moveCol, player);
    cout << "CPU chooses: " << moveRow << " " << moveCol << endl;
}

int minimax(Board& board, int depth, bool isMaximizing, char player, int alpha, int beta) {
    char opponent = (player == PLAYER_X) ? PLAYER_O : PLAYER_X; // Determine the opponent

    // Base cases
    if (checkWin(board, player)) return 10 - depth; // Favor quicker wins
    if (checkWin(board, opponent)) return depth - 10; // Penalize slower losses
    if (board.isFull()) return 0; // Draw

    int bestScore = isMaximizing ? -1000 : 1000; // Initialize bestScore

    // Explore all possible moves
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (board.getCellValue(i, j) == EMPTY) { // Check only empty cells
                board.setCell(i, j, isMaximizing ? player : opponent); // Simulate the move
                int score = minimax(board, depth + 1, !isMaximizing, player, alpha, beta); // Recurse
                board.setCell(i, j, EMPTY); // Undo the move

                // Update bestScore and alpha-beta bounds
                if (isMaximizing) {
                    bestScore = max(bestScore, score);
                    alpha = max(alpha, bestScore);
                }
                else {
                    bestScore = min(bestScore, score);
                    beta = min(beta, bestScore);
                }

                if (beta <= alpha) return bestScore; // Prune the search
            }
        }
    }

    return bestScore;
}

bool checkWin(Board& board, char player) {
    // Check rows and columns for a win
    for (int i = 0; i < 3; ++i) {
        if (board.getCellValue(i, 0) == player && board.getCellValue(i, 1) == player && board.getCellValue(i, 2) == player)
            return true;
        if (board.getCellValue(0, i) == player && board.getCellValue(1, i) == player && board.getCellValue(2, i) == player)
            return true;
    }

    // Check diagonals for a win
    if (board.getCellValue(0, 0) == player && board.getCellValue(1, 1) == player && board.getCellValue(2, 2) == player)
        return true;
    if (board.getCellValue(0, 2) == player && board.getCellValue(1, 1) == player && board.getCellValue(2, 0) == player)
        return true;

    return false; // No win detected
}
